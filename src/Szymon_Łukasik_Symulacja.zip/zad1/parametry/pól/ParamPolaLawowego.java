package zad1.parametry.pól;

public class ParamPolaLawowego {

    private int ileZadajeLawa;

    public int ileZadajeLawa() {
        return ileZadajeLawa;
    }

    public void ustawIleZadajeLawa(int ileZadajeLawa) {
        this.ileZadajeLawa = ileZadajeLawa;
    }
}
