package zad1.parametry.pól;

public class ParamPolaŻywieniowego {

    private int ileRośnieJedzenie;

    public int ileRośnieJedzenie() {
        return ileRośnieJedzenie;
    }

    public void ustawIleRośnieJedzenie(int ileRośnieJedzenie) {
        this.ileRośnieJedzenie = ileRośnieJedzenie;
    }
}
